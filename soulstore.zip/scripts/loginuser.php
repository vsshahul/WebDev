<?php
$name = ($_POST["useremail"]);
echo $name;
$pswd = ($_POST["userpswd"]);
echo $pswd;
?>