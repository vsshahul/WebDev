<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/design.css" type="text/css"> 
    <link rel="stylesheet" href="/css/responsive.css" type="text/css">
    <link rel = "icon" href = "/images/cart.png" type = "image/x-icon"> 
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Montserrat:300&display=swap" rel="stylesheet">
    <title>News Letter</title>
    <style>


.navbar a.right{
  background-color: rgba(0,0,0,0);
}
.navbar{
  background-color: #5A6882;
  height: 100px;
  width: 100%;;
}
.flexcont{
  display: flex;
  justify-content: flex-start;
}
.leftcont, .rightcontainer{
  padding: 30px 60px;
}
.leftcont>p{
  padding: 0px;
  margin: 0px;
}
.blocks>.FAQ>a ,.blocks>.followus>a{
  display: block;
  padding: 1px;
  margin: 3px;
  text-decoration: none;
  color: #5A6882;
}
.blocks{
  color: #5A6882;
}
.helpCont>.sideBar{
  position: sticky;
  height: 100%;
  width: 30%;
  z-index: 1;
 top: 0;
  left: 0;
  
}


</style>
</head>
<body>

<!-- HEADER CONTENT ONLY -->
<div class="navbar">
        
        <div id="soul"><a href="/index.php" style="color: white;">Soul Store</a></div>
        
         <div class="nav-container">
          <a href="/src/men.php">Men</a>
          <a href="/src/women.php">Women</a>
          <a href="/src/objects.php">Objects</a>
        </div>
        
          <div class="right-nav">
          <a href="#" class="right cart"> <img src="/images/cart.png"> </a>
          <a href="/src/login.php" class="right">Log in</a>
          <a href="/src/help.php" class="right">Help</a>
          <a href="/src/contactus.php" class="right">Contact Us</a>
        </div>
        
		</div>
		

<?php
$cName = ($_POST["custEmail"]);
echo "<p>Your Email has been recieved.</p>" .$cName;
?>
<?php include '../footerCommon.html'?>
</body>
</html>

