<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 

<link rel="stylesheet" href="../css/design.css" type="text/css"> 
<link rel="stylesheet" href="../css/responsive.css" type="text/css">

<link rel = "icon" href = "../images/cart.png" type = "image/x-icon"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Montserrat:300&display=swap" rel="stylesheet">

<title>SoulStore-Help</title> 
<link rel = "icon" href = "image\cart.png" type = "image/x-icon"> 

<style>


.navbar a.right{
  background-color: rgba(0,0,0,0);
}
.navbar{
  background-color: #5A6882;
  height: 100px;
  width: 100%;;
}
.flexcont{
  display: flex;
  justify-content: flex-start;
}
.leftcont, .rightcontainer{
  padding: 30px 60px;
}
.leftcont>p{
  padding: 0px;
  margin: 0px;
}
.blocks>.FAQ>a ,.blocks>.followus>a{
  display: block;
  padding: 1px;
  margin: 3px;
  text-decoration: none;
  color: #5A6882;
}
.blocks{
  color: #5A6882;
}
.helpCont>.sideBar{
  position: sticky;
  height: 100%;
  width: 30%;
  z-index: 1;
 top: 0;
  left: 0;
  
}


</style>

</head>
<body> 
<!-- HEADER CONTENT ONLY -->
<div class="navbar">
        
        <div id="soul"><a href="/index.php" style="color: white;">Soul Store</a></div>
        
         <div class="nav-container">
          <a href="/src/men.php">Men</a>
          <a href="/src/women.php">Women</a>
          <a href="/src/objects.php">Objects</a>
        </div>
        
          <div class="right-nav">
          <a href="/src/cartpage.php" class="right cart"> <img src="/images/cart.png"> </a>
          <a href="/login/login.php" class="right">Log in</a>
          <a href="/src/help.php" class="right">Help</a>
          <a href="/src/contactus.php" class="right">Contact Us</a>
        </div>
        
		</div>
		
<!-- MAIN CONTENT GOES HERE -->
<div class="main">
    <div class="helpCont">
        <div class="sideBar">
           <div class="blocks">
              <div class="FAQ">
                  <h2>FAQ</h2>
              <a href="#" >About Ugmonk</a>
              <a href="#" >Orders</a>
              <a href="#" >Shipping</a>
              <a href="#" >Returns & Exchanges</a>
              <a href="#" >Product</a>
              <a href="#" >Miscellaneous</a>

          </div>
           </div>
           <div class="blocks">
             <div class="mailAdd">
              <h2>Mailing Address</h2>
          <p>Royapettah,<br>Chennai <br>Tamil Nadu. <br></p>
      </div>
    </div>
           <div class="blocks">
              <div class="followus">
                  <h2>Follow Us</h2>
              <a href="#" title="Shahul">Instagram</a>
              <a href="#" title="Shahul">Facebook</a>
              <a href="#" title="Shahul">LinkedIn</a>
          </div>


           </div>
        </div>
        <div class="pageCont">
            <h2>How Can We Help You?</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
    
        </div>
        <script>
            var acc = document.getElementsByClassName("accordion");
            var i;
            
            for (i = 0; i < acc.length; i++) {
              acc[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var panel = this.nextElementSibling;
                if (panel.style.display === "block") {
                  panel.style.display = "none";
                } else {
                  panel.style.display = "block";
                }
              });
            }
            </script>
            
</div>
<!-- FOOTER CONTENT ONLY -->
<?php include '../footerCommon.html'; ?>
</body>
</html>