<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Soul Store -Buy</title>
    
<link rel="stylesheet" href="../css/design.css" type="text/css"> 
<link rel="stylesheet" href="../css/responsive.css" type="text/css">

<link rel = "icon" href = "../images/cart.png" type = "image/x-icon"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Montserrat:300&display=swap" rel="stylesheet">
<style>

.navbar{
  height: 100px;
  z-index: -1;
  background-color: rgba(6, 6, 6, 0.41);
  }
.product{
  display: flex;
  padding: 20px;
}
.imageCont{
 padding: 50px;
  flex: 1;
}
.imageCont>img{
  height: 400px;
}
.productdetails{
  padding: 20px;
  flex: 2;
}
.productdetails>p{
  width: 500px;
}
.shopbtn{
  margin-left: 0px;
  width: 200px;
}
</style>
</head>
<body>
<!-- HEADER CONTENT ONLY -->
<div class="navbar">
        
        <div id="soul"><a href="/index.php" style="color: white;">Soul Store</a></div>
         <!-- bar -->
         <div class="opennavdiv" style="font-size:30px;cursor:pointer" onclick="openNav()" >
         <div class="containerbar" onclick="barFunction(this)">
          <div class="bar1"></div>
          <div class="bar2"></div>
          <div class="bar3"></div>
        </div>
        </div>
        <!--  -->
        <div id="mySidenav" class="sidenav" >
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
         <div class="nav-container">
          <a href="/src/men.php">Men</a>
          <a href="/src/women.php">Women</a>
          <a href="/src/objects.php">Objects</a>
        </div>
        
          <div class="right-nav">
          <a href="#" class="right cart"> <img src="/images/cart.png"> </a>
          <a href="/src/login.php" class="right">Log in</a>
          <a href="/src/help.php" class="right">Help</a>
          <a href="/src/contactus.php" class="right">Contact Us</a>
         
        </div>
        </div>
        </div>

<!-- MAIN CONTENT GOES HERE -->
<div class="main">
    <div class="product">
        <div class="imageCont">
            <img src="../images/men/3.jpeg" alt="Product Image"/>

        </div>
        <div class="productdetails">
            <h2>Product Name</h2>
            <p>Product small description</p>
            <p>Price Rs.$$$$</p>
            <button class="shopbtn">+ Add to Cart</button>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Excepturi, fuga aliquam cumque cupiditate repellendus ut optio reprehenderit reiciendis nihil vel ipsa accusantium, deserunt laboriosam nisi sit enim et unde? Modi?</p>
        </div>
    </div>
</div>
<!-- FOOTER CONTENT ONLY -->
<?php
include '../footerCommon.html';
?>

</body>
</html>