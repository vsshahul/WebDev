<!DOCTYPE html>
<html>
<head>
<title>SoulStore-Womens</title> 
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="../css/design.css" type="text/css"> 
<link rel="stylesheet" href="../css/responsive.css" type="text/css">

<link rel = "icon" href = "../images/cart.png" type = "image/x-icon"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Montserrat:300&display=swap" rel="stylesheet">
<style>
.headermain{
background: url(../images/womenheader.jpg)no-repeat center ;
}
</style>
</head>
<body>
<!-- HEADER CONTENT ONLY -->
<?php 
include '../headerCommon.html';
?>
<!-- MAIN CONTENT GOES HERE -->
<div class="main">

<?php
include '../productList.html';
?>

</div>

<!-- FOOTER CONTENT ONLY -->
<?php
include '../footerCommon.html';
?>

</body>
</html>