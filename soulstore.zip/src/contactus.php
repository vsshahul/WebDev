
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../css/design.css" type="text/css"> 
<link rel="stylesheet" href="../css/responsive.css" type="text/css">

<link rel = "icon" href = "../images/cart.png" type = "image/x-icon"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Montserrat:300&display=swap" rel="stylesheet">
    <title>login page</title>
<title>SoulStore-Contact US</title> 
<link rel = "icon" href = "image\cart.png" type = "image/x-icon"> 
<style>

.navbar a.right{
  background-color: rgba(0,0,0,0);
}

.navbar{
  background-color: #5A6882;
  height: 100px;
  width: 100%;;
}

/* contactus */
.mainContact{
  display: flex;
  padding: 50px;
  
}
.flexbox1{
  flex: 2;
}
.flexbox1>div>h2{
  margin: 10px 0px;
  padding: 10px 0px;
}
.flexbox1>div{
  padding: 0px 0px;
}
.flexbox1>div>p{
  padding: 10px;
  margin: 0px;
}
.flexbox1>div>a{
  text-decoration: none;
  color: gray;
}

.flexbox5{
  flex: 4;
}
.flexbox5>ul>li>a{
  list-style-type: none;
  color: black;
}
.followus>a{
  padding: 10px;
  display: block;
}
.followus>a:hover{
  color: lightseagreen;
}
.formMessage{
  font-size: 14px;
}
.formMessage>form>input{
  width: 50%;;
  height: 30px;
  margin: 10px 0px;
}
.formMessage>form>textarea{
  width: 50%;
  height: 150px;
}
span{
  color: red;
}

.shopbtn{
 width: auto;
  padding: 10px 20px;
   margin: 10px 0px
}
form>p{
text-align: left;
  width: 500px;
}

@media screen and (max-width:850px ){
  .mainContact{
    flex-direction: column;
  }
 
}
@media screen and (max-width:550px ){
  h2{
    font-size: 4vw;
  }
  p{
    font-size: 3vw;
  }
  a{
    font-size: 3vw;
  }
  .formMessage>form>input{
   width: 100%;
  }
  .formMessage>form>textarea{
   width: 100%;
 
  }
  form>p{
    text-align: left;
  }
}


</style>
</head>
<body>
<!-- HEADER CONTENT ONLY -->
<div class="navbar">
        
        <div id="soul"><a href="/index.php" style="color: white;">Soul Store</a></div>
        
         <div class="nav-container">
          <a href="/src/men.php">Men</a>
          <a href="/src/women.php">Women</a>
          <a href="/src/objects.php">Objects</a>
        </div>
        
          <div class="right-nav">
          <a href="/src/cartpage.php" class="right cart"> <img src="/images/cart.png"> </a>
          <a href="/login/login.php" class="right">Log in</a>
          <a href="/src/help.php" class="right">Help</a>
          <a href="/src/contactus.php" class="right">Contact Us</a>
        </div>
        
		</div>
		

<!-- MAIN CONTENT GOES HERE -->
<div class="mainContact">
    <div class="flexbox1">
        <div class="mailaddr">
            <h2>Mail Address</h2>
            <p>Royapettah,</p>
            <p>Chennai,</p>
            <p>Tamil Nadu.</p>
        </div>
        <div class="followus">
                <h2>Follow Us</h2>
            <a href="https://twitter.com/vs_shahul" title="Shahul">Twitter</a>
            <a href="https://www.facebook.com/vsshahul1" title="Shahul">Facebook</a>
            <a href="https://www.linkedin.com/in/shahulVS" title="Shahul">LinkedIn</a>
        </div>
    </div>
    <div class="flexbox5">
            <h2>Have a question? we're here to help.</h2>
            <p>A few links that might point you in the right direction:</p>
            <ul>
                <!-- <li><a href="#"></a></li> -->
                <li><a href="#">Return & Exchanges</a></li> <br/>
                <li><a href="#">Sizing & Fit</a></li> <br/>
                <li><a href="#">General Questions about SoulStore</a></li> <br/>
            </ul>
        <div class="formMessage">
            <form action="/scripts/message.php" method="POST">
                <h2>Send us a message</h2>
                Email<span>*</span><br/>
                <input type="email" name="mesEmail"><br/>
                Name<br/>
                <input type="text" name="mesName"><br/>
                Subject<span>*</span><br/>
                <input type="text" name="mesSubject"><br/>
                Message<span>*</span><br/>
                <textarea name="commentArea" >
                </textarea><br/>

                <button class="shopbtn" type="submit" onclick="xzx">Send Message</button>
                <p>Or email us directly @ vsshahul737@gmail.com </p>
            </form>   
            <div class="displaymessage">
           
            </div>
        </div>
    </div>
</div>

<!-- FOOTER CONTENT ONLY -->

<?php include '../footerCommon.html'; ?>

</body>
</html>
