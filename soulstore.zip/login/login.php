<!DOCTYPE html>
<!--PHP login System -->
<html>
<head>
<meta charset="utf-8">
<title>Soul Store-Login</title>

<link rel="stylesheet" href="../css/design.css" type="text/css"> 
<link rel="stylesheet" href="../css/responsive.css" type="text/css">

<link rel = "icon" href = "../images/cart.png" type = "image/x-icon"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Montserrat:300&display=swap" rel="stylesheet">

<link rel="stylesheet" href="style.css" />
<style>
/* header */
.navbar a.right{
  background-color: rgba(0,0,0,0);
}

.navbar{
  background-color: #5A6882;
  height: 100px;
  width: 100%;;
}
.flexcont{
  display: flex;
  justify-content: flex-start;
}
.leftcont, .rightcontainer{
  padding: 30px 60px;
}
.leftcont>p{
  padding: 0px;
  margin: 0px;
}
/* LOGIN PAGE CSS */ 

.userLoginCont{
  width: 100%;

  padding: 10px;
  background-color: white;
}

.LoginWelcome>h2{
  margin: 30px 0px;
}
.LoginWelcome>p{
  font-size: 15px;
  color: #1b1c2c;
  margin-bottom: 30px;
}
.usrnameCont>input, .pswdCont>input{
  border: none;
  padding: 10px;
  background-color: white;
  border: 1px solid grey;
  width: 300px;
  height: 30px;
  margin-bottom:10px;
  font-size: 15px;
}
.loginInputDetails{
  font-size: 10px;
}
.loginInputDetails :hover{
  background-color: black;
  color: white;
  font-size: 12px;
  opacity: .8;
  transition: .5s ease-in-out;
}

.Loginbtn{
 
  background-color:#5A6882 ;
  color: white;
  border: none;
  padding:10px 20px;
  margin: 10px 0px;
  font-size: 15px;
}
.Loginbtn:hover{
  background-color: gray;
  transition: .5s ease-in-out;
}
.card{
  border-radius: 3px;
  box-shadow: 0px 0px 6px grey;
  padding: 10px 20px;
}
.icons>a>i{
  text-decoration: none;
  color: black;
  padding: 10px;
  font-size: 20px;
  background-color: lightgray;
  border-radius:10px;
  
}
.icons>a>i:hover{
  color: white;
  background-color: black;
  transition: 1s;
}

.footer-container-upper{
  background-color: #5A6882;
}  


</style>
</head>
<body>
<?php
require('db.php');
session_start();
if (isset($_POST['username'])){
	$username = stripslashes($_REQUEST['username']);
	$username = mysqli_real_escape_string($con,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
        $query = "SELECT * FROM `users` WHERE username='$username'
and password='".md5($password)."'";
	$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['username'] = $username;
	    header("Location: ../index.php");
         }else{
	echo "<div class='form'>
<h3>Username/password is incorrect.</h3>
<br/>Click here to <a href='login.php'>Login</a></div>";
	}
    }else{
?>
<!--
	<form class="login" action="" method="post" name="login">
    <h1 class="login-title">Login</h1>
    <input type="text" class="login-input" name="username" placeholder="Username" autofocus>
    <input type="password" class="login-input" name="password" placeholder="Password">
    <input type="submit" value="Login" name="submit" class="login-button">
  <p class="login-lost">New Here? <a href="registration.php">Register</a></p>
  </form>
-->

<!-- HEADER CONTENT ONLY -->
<div class="navbar">
        
        <div id="soul"><a href="/index.php">Soul Store</a></div>
        
         <div class="nav-container">
          <a href="/src/men.php">Men</a>
          <a href="/src/women.php">Women</a>
          <a href="/src/objects.php">Objects</a>
        </div>
        
          <div class="right-nav">
		  <a href="/login/logout.php" class="right">Logout</a>
          <a href="/src/cartpage.php" class="right cart"> <img src="/images/cart.png"> </a>
          <a href="/src/login.php" class="right">Log in</a>
          <a href="/src/help.php" class="right">Help</a>
          <a href="/src/contactus.php" class="right">Contact Us</a>
        </div>
        
		</div>
		

<!-- login -->
<div class="userLoginCont">
	<form action="" method="post" name="login">
		<div class="flexcont">
		<div class="leftcont">
	<div class="LoginWelcome">
		<h2>Login to your account</h2>
	</div>
  <div class="card">
	<p>Enter Username</p><br/>
	<div class="usrnameCont"><input class="loginInputDetails" type="text" name="username" placeholder="username" ></div>
	<p>Enter Password</p><br/>
	<div class="pswdCont"><input class="loginInputDetails" type="password" name="password" placeholder="Password" ></div>
	<div class="btnCont">
		<button class="Loginbtn" type="submit" value="login" name="submit" >Login Now</button>
		<p class="login-lost">New Here? <a href="registration.php">Register</a></p>
    </div>
		<!--  -->
	</div>

</div>
<div class="rightcontainer">
<div class="LoginWelcome">
		<h2>Create new account</h2>
		<p>To keep connected with us please login with your email adderess and password</p>
		<button class="Loginbtn">Create Account</button>
	</div>
	<div class="join">
		<p>or you can join with</p>
		<div class="icons">
			<a href="https://www.facebook.com/vsshahul1"><i class="fa fa-facebook-official"></i></a>
			<a href="https://twitter.com/vs_shahul"><i class="fa fa-twitter" ></i></a>
			<a href="https://www.google.com/"><i class="fa fa-google"></i></a>
		</div>

	</div>
</div>
</div>
	</form>
</div>

<!-- FOOTER CONTENT ONLY -->
<?php include '../footerCommon.html'; ?>


<?php } ?>
</body>
</html>